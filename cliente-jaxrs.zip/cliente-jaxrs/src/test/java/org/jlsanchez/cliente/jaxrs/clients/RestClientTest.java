package org.jlsanchez.cliente.jaxrs.clients;

import jakarta.ws.rs.core.Response;
import org.jlsanchez.cliente.jaxrs.models.Curso;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RestClientTest {

    public static final int HTTP_CREATED = 200;
    public static final int HTTP_NOTCONTENT = 204;
    private RestClient client = new RestClient();


    @Test
    void getJsonCurso() {
        int id=4;
      Response response=client.getJsonCurso(id);
      Curso curso=response.readEntity(Curso.class);
        System.out.println("curso.getNombre() = " + curso.getNombre());
      assertEquals(response.getStatus(), HTTP_CREATED);
    }

    @Test
    void createJsonCurso() {

       Curso curso= new Curso();
       curso.setNombre("React");
       curso.setDescripcion("es un curso de react");
       curso.setDuracion(20.3);
       curso.setInstructor("andres");
       Response response = client.createJsonCurso(curso);
       int status=response.getStatus();
        System.out.println("estado: "+status);
        curso=response.readEntity(Curso.class);
        System.out.println("nuevo curso:" + curso.getNombre());

        assertEquals(response.getStatus(), HTTP_CREATED);
    }

    @Test
    void listarJsonCursos(){
        Response response = client.listarJsonCurso();
        assertEquals(response.getStatus(), HTTP_CREATED);
    }

    @Test
    void actualizarJsonCursos(){
        Curso curso= new Curso();
        curso.setNombre("React nuevo");
        curso.setDescripcion("es un curso de react");
        curso.setDuracion(20.3);
        curso.setInstructor("andres mejia");
        Response response = client.actualizarJsonCurso(4,curso);
        curso= response.readEntity(Curso.class);
        System.out.println("nuevo nombre = " + curso.getNombre());
        assertEquals(response.getStatus(), HTTP_CREATED);
    }

    @Test
    void deleteJsonCursos(){
        Response response = client.deleteJsonCurso(3);
        System.out.println("response.getStatus() = " + response.getStatus());
       assertEquals(response.getStatus(),HTTP_NOTCONTENT);
    }


}