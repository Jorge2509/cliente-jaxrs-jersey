package org.jlsanchez.cliente.jaxrs.clients;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jlsanchez.cliente.jaxrs.models.Curso;



public class RestClient  {

    private static final String REST_URI
            = "http://localhost:8080/webapp-jaxrs-jpa/api/cursos";

    private Client client = ClientBuilder.newClient();

    public Response getJsonCurso(int id) {

        return client
                .target(REST_URI)
                .path(String.valueOf(id))
                .request(MediaType.APPLICATION_JSON)
                .get();

    }

    public Response createJsonCurso(Curso curso) {
        return client
                .target(REST_URI)
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(curso, MediaType.APPLICATION_JSON));
    }

    public Response listarJsonCurso() {
        return client
                .target(REST_URI)
                .request(MediaType.APPLICATION_JSON)
                .get();

    }

    public Response actualizarJsonCurso(int id, Curso curso) {
        return client
                .target(REST_URI)
                .path(String.valueOf(id))
                .request(MediaType.APPLICATION_JSON)
                .put(Entity.entity(curso, MediaType.APPLICATION_JSON));

    }

    public Response deleteJsonCurso(int id) {
        return client
                .target(REST_URI)
                .path(String.valueOf(id))
                .request(MediaType.APPLICATION_JSON)
                .delete();

    }


}
